import pandas as pd
import time

class my_model():
    def fit(self, X, y):
        # do not exceed 29 mins
        return

    def predict(self, X):
        # remember to apply the same preprocessing in fit() on test data before making predictions
        return predictions



