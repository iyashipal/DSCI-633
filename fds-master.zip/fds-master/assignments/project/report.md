https://docs.google.com/presentation/d/1mU_p8OV6qT8T7Z2lLxyF1T6HRlMOQpuiAEiEizBfCoM/edit#slide=id.p
